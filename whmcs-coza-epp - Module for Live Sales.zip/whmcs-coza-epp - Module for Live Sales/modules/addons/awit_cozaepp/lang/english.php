<?php

$_ADDONLANG['intro'] = "AWIT COZAEPP Module";
$_ADDONLANG['description'] = "This module is to facilitate displaying of epp messages.";
$_ADDONLANG['documentation'] = "Pending..";

