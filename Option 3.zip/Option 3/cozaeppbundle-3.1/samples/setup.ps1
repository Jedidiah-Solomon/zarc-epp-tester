# setup.ps1 - For Windows PowerShell users
# Run: .\setup.ps1

Write-Host "Generating login files..." -ForegroundColor Cyan

# Load environment variables from .env if it exists
if (Test-Path ".env") {
    Write-Host "Loading environment variables from .env" -ForegroundColor Yellow
    Get-Content ".env" | ForEach-Object {
        if ($_ -match '^([^=]+)=(.*)$') {
            [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process')
        }
    }
} else {
    Write-Host "No .env file found. Please create one with your ZARC credentials." -ForegroundColor Red
    Write-Host "Required variables:" -ForegroundColor Yellow
    Write-Host "  ZARC_USERNAME=your_username"
    Write-Host "  ZARC_PASSWORD=your_password"
    Write-Host "  ZARC_USERNAME_SECONDARY=your_username-2"
    Write-Host "  ZARC_PASSWORD_SECONDARY=your_password"
    exit 1
}

# Check if required variables are set
if (-not $env:ZARC_USERNAME -or -not $env:ZARC_PASSWORD) {
    Write-Host "Error: ZARC_USERNAME and ZARC_PASSWORD must be set in .env file" -ForegroundColor Red
    exit 1
}

# Primary login
if (Test-Path "login.template.xml") {
    $content = Get-Content "login.template.xml" -Raw
    $content = $content -replace "__ZARC_USERNAME__", $env:ZARC_USERNAME
    $content = $content -replace "__ZARC_PASSWORD__", $env:ZARC_PASSWORD
    $content | Set-Content "login.xml" -NoNewline
    Write-Host "  [OK] login.xml created" -ForegroundColor Green
} else {
    Write-Host "  [ERROR] login.template.xml not found!" -ForegroundColor Red
}

# Secondary login
if (Test-Path "login_secondary.template.xml") {
    $content = Get-Content "login_secondary.template.xml" -Raw
    $content = $content -replace "__ZARC_USERNAME_SECONDARY__", $env:ZARC_USERNAME_SECONDARY
    $content = $content -replace "__ZARC_PASSWORD_SECONDARY__", $env:ZARC_PASSWORD_SECONDARY
    $content | Set-Content "login_secondary.xml" -NoNewline
    Write-Host "  [OK] login_secondary.xml created" -ForegroundColor Green
} else {
    Write-Host "  [ERROR] login_secondary.template.xml not found!" -ForegroundColor Red
}

Write-Host ""
Write-Host "Done! Files are ready to use." -ForegroundColor Green
Write-Host "To test: python epp.py --host=ote.zarc.net.za --port=700 --cert=./certificates/epp.pem --verbose login.xml" -ForegroundColor Yellow