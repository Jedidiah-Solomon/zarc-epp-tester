#!/bin/bash
# setup.sh - Create login files from templates
# Usage: ./setup.sh

# Load environment variables from .env if it exists
if [ -f .env ]; then
    echo "Loading environment variables from .env"
    export $(grep -v '^#' .env | xargs)
else
    echo "No .env file found. Please create one with your ZARC credentials."
fi

# Check if required variables are set
if [ -z "$ZARC_USERNAME" ] || [ -z "$ZARC_PASSWORD" ]; then
    echo "Error: ZARC_USERNAME and ZARC_PASSWORD must be set in .env file"
    echo "Create a .env file with:"
    echo "  ZARC_USERNAME=your_username"
    echo "  ZARC_PASSWORD=your_password"
    echo "  ZARC_USERNAME_SECONDARY=your_username-2"
    echo "  ZARC_PASSWORD_SECONDARY=your_password"
    exit 1
fi

echo "Generating login files..."

# Primary login
if [ -f login.template.xml ]; then
    cp login.template.xml login.xml
    sed -i "s/__ZARC_USERNAME__/${ZARC_USERNAME}/g" login.xml
    sed -i "s/__ZARC_PASSWORD__/${ZARC_PASSWORD}/g" login.xml
    echo "  - login.xml created"
else
    echo "  - login.template.xml not found!"
fi

# Secondary login
if [ -f login_secondary.template.xml ]; then
    cp login_secondary.template.xml login_secondary.xml
    sed -i "s/__ZARC_USERNAME_SECONDARY__/${ZARC_USERNAME_SECONDARY}/g" login_secondary.xml
    sed -i "s/__ZARC_PASSWORD_SECONDARY__/${ZARC_PASSWORD_SECONDARY}/g" login_secondary.xml
    echo "  - login_secondary.xml created"
else
    echo "  - login_secondary.template.xml not found!"
fi

echo ""
echo "Done! Files are ready to use."