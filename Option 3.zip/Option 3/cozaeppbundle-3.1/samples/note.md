1. First, make sure your .env file has the credentials:
2. Then Run your setup script to generate login.xml: `./setup.sh`

```
# On Linux/Mac/Git Bash
chmod +x setup.sh
./setup.sh

or

# On Windows PowerShell
.\setup.ps1
```

3. Verify Files Created
   bash
   ls login\*.xml
   You should see:

login.template.xml (original template)

login.xml (generated with your credentials)

login_secondary.template.xml (original template)

login_secondary.xml (generated with your credentials)

4. Test the Connection ``python epp.py --host=epp.zarc.net.za --port=700 --cert=./certificates/epp.pem --verbose login.xml`
5.

Note: Ensure your IP is on ZARC

```
🔍 Find Your Current IP
powershell
# Quick check
curl ifconfig.me
# or
(Invoke-WebRequest -uri "http://api.ipify.org").Content
```

5. Create Contact `python epp.py --host=epp.zarc.net.za --port=700 --cert=./certificates/epp.pem --verbose login.xml create_contact_precious.xml`

---

1. Check network: `python epp.py --host=ote.zarc.net.za --port=700 --nossl --ng --verbose`

2. Check content of te file: ``type login.xml`

3. Login: `python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml`

4. Create Contact: `python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_domain_7.xml`

```

```

# List all our files to confirm

dir create\_\*.xml

# 1. Create contacts (if not already done)

python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_contact_1.xml

python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_contact_2.xml

# 2. Create hosts

python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_host_1.xml

python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_host_2.xml

# 3. Create domain

python epp.py --host=ote.zarc.net.za --port=700 --verbose login.xml create_domain_1.xml

```

```
